import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class UserListService {
  constructor(private http: HttpClient) {}

  getUserDetailList(onSuccess: Function, onError: Function) {
    this.http
      .get("https://ewjgauic6f.execute-api.eu-central-1.amazonaws.com/production/userdetails", {
        headers: new HttpHeaders({
          "Accept-Language": "en-US",
          "Content-Type": "application/json"
        })
      })
      .subscribe(
        response => {
          onSuccess(response);
        },
        error => {
          onError(error);
        }
      );
  }
}
