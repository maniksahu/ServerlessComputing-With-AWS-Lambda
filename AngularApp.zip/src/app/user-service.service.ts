import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable({
  providedIn: "root"
})
export class UserServiceService {
  private serviceUrl: string =
    "https://ewjgauic6f.execute-api.eu-central-1.amazonaws.com/production";

  constructor(private http: HttpClient) {}

  //Add new user details
  addUserDetails(userDetails: any, onSuccess: Function, onError: Function) :void {
    this.http
      .post(this.serviceUrl + "/addUserDetails", userDetails, {
        headers: new HttpHeaders({
          "Accept-Language": "en-US",
          "Content-Type": "application/json"
        })
      })
      .subscribe(
        (response: Response) => {
          console.log(response);
          this.getUserDetailList(onSuccess, onError)
        },
        (error: Error) => {
          console.log(error);
        }
      );
  }

  getUserDetailList(onSuccess: Function, onError: Function) :void {
    this.http
      .get(this.serviceUrl + "/userDetailsList", {
        headers: new HttpHeaders({
          "Accept-Language": "en-US",
          "Content-Type": "application/json"
        })
      })
      .subscribe(
        response => {
          onSuccess(response);
        },
        error => {
          onError(error);
        }
      );
  }
}
