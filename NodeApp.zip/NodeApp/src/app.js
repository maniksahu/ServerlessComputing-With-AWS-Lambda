const express = require("express");
const app = express();

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});

let userDetails = [
  {
    firstName: "User 1",
    lastName: "1",
    address: {
      streetAddress:
        "HUB 1 , Building of SEZ Towers, Karle Town Centre, DadaMastan Layout, Manayata Tech Park, Nagavara",
      city: "Bengaluru",
      state: "Karnataka",
      postalCode: "560045"
    }
  },
  {
    firstName: "User 2",
    lastName: "2",
    address: {
      streetAddress:
        "HUB 1 , Building of SEZ Towers, Karle Town Centre, DadaMastan Layout, Manayata Tech Park, Nagavara",
      city: "Bengaluru",
      state: "Karnataka",
      postalCode: "560045"
    }
  },
  {
    firstName: "User 3",
    lastName: "3",
    address: {
      streetAddress:
        "HUB 1 , Building of SEZ Towers, Karle Town Centre, DadaMastan Layout, Manayata Tech Park, Nagavara",
      city: "Bengaluru",
      state: "Karnataka",
      postalCode: "560045"
    }
  },
  {
    firstName: "User 4",
    lastName: "4",
    address: {
      streetAddress:
        "HUB 1 , Building of SEZ Towers, Karle Town Centre, DadaMastan Layout, Manayata Tech Park, Nagavara",
      city: "Bengaluru",
      state: "Karnataka",
      postalCode: "560045"
    }
  },
  {
    firstName: "User 5",
    lastName: "5",
    address: {
      streetAddress:
        "HUB 1 , Building of SEZ Towers, Karle Town Centre, DadaMastan Layout, Manayata Tech Park, Nagavara",
      city: "Bengaluru",
      state: "Karnataka",
      postalCode: "560045"
    }
  },
  {
    firstName: "User 6",
    lastName: "6",
    address: {
      streetAddress:
        "HUB 1 , Building of SEZ Towers, Karle Town Centre, DadaMastan Layout, Manayata Tech Park, Nagavara",
      city: "Bengaluru",
      state: "Karnataka",
      postalCode: "560045"
    }
  },
  {
    firstName: "User 7",
    lastName: "7",
    address: {
      streetAddress:
        "HUB 1 , Building of SEZ Towers, Karle Town Centre, DadaMastan Layout, Manayata Tech Park, Nagavara",
      city: "Bengaluru",
      state: "Karnataka",
      postalCode: "560045"
    }
  }
];
app.get("/", (req, res) => {
  res.status(200).send("Welcome to lambda node service");
});

app.get("/userDetailsList", (req, res) => {
  res.send(userDetails);
});

module.exports = app;
